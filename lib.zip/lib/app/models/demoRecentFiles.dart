class Orders {
  final String id, name, email, status;
  final double total;
  final String date;

  Orders({this.id, this.name, this.date, this.status,this.total,this.email});
}


