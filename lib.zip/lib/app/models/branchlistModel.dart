class BranchListModel{

  BranchListModel({this.index, this.bName,this.address, this.phn, this.location,});
  final int index;
  final String bName;
  final String address;
  final String phn;
  final String location;

}