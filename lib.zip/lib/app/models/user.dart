class Usuario {
  Usuario({this.codigo, this.other,this.nome, this.email, this.telefone, this.endereco});
  final int codigo;
  final String nome;
  final String email;
  final String telefone;
  final String endereco;
  final String other;
}
