import 'package:flutter/material.dart';

const secondaryColor = Color.fromRGBO(179,31,93, 1);
